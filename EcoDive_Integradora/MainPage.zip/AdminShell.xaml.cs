namespace EcoDive_Integradora;

public partial class AdminShell : Shell
{
    public AdminShell()
    {
        InitializeComponent();
    }
}
