﻿using Microsoft.Maui.Controls;

namespace EcoDive_Integradora.Views
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            var appShell = Application.Current.MainPage as AppShell;
            string correo = appShell?.UsuarioCorreo ?? "Correo no disponible";

            BienvenidaLabel.Text = $"Bienvenido: {correo}";
        }

        private async void OnListProductClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ListProductsPage());
        }

        private async void OnResponderTriviaClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new TriviaPage());
        }

        private async void OnVerRespuestasClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ListTriviaPage());
        }

        private async void OnSalirClicked(object sender, EventArgs e)
        {
            bool confirmar = await DisplayAlert("Cerrar sesión", "¿Estás seguro que deseas salir?", "Sí", "No");
            if (confirmar)
            {
                // Si usas Firebase Auth o Preferences, podrías limpiar datos aquí
                // await FirebaseAuthService.Logout(); // si lo implementas
                // Preferences.Clear();

                Application.Current.MainPage = new NavigationPage(new LoginPage());
            }
        }
    }
}
