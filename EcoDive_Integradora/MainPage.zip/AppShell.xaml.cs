﻿using EcoDive_Integradora.Views;
using System;

namespace EcoDive_Integradora
{
    public partial class AppShell : Shell
    {
        public string UsuarioCorreo { get; private set; }

        public AppShell(string correoUsuario)
        {
            InitializeComponent();
            UsuarioCorreo = correoUsuario;

            // Opcional: puedes mostrarlo, registrarlo o pasarlo a otras páginas
            Console.WriteLine($"Usuario logueado: {UsuarioCorreo}");

            // Puedes configurar rutas, navegación u otros ajustes aquí
        }

        // Constructor vacío por si lo necesitas en otra parte
        public AppShell() : this("correo_desconocido@ejemplo.com")
        {
        }
    }
}
