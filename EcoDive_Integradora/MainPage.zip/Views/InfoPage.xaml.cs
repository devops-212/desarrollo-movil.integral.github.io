using Microsoft.Maui.Controls;

namespace EcoDive_Integradora.Views
{
    public partial class InfoPage : ContentPage
    {
        public InfoPage()
        {
            InitializeComponent();
        }
    }
}
