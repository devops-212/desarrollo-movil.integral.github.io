using EcoDive_Integradora.Models;
using EcoDive_Integradora.Helpers;

namespace EcoDive_Integradora.Views;

public partial class EditStatusPage : ContentPage
{
    private Producto _producto;
    private readonly FirebaseHelper _firebaseHelper = new FirebaseHelper();

    public EditStatusPage(Producto producto)
    {
        InitializeComponent();
        _producto = producto;

        CategoriaPicker.SelectedItem = _producto.Categoria;
        SubcategoriaPicker.SelectedItem = _producto.Subcategoria;
        EstadoPicker.SelectedItem = _producto.Estado;
    }

    private async void OnGuardarClicked(object sender, EventArgs e)
    {
        _producto.Categoria = CategoriaPicker.SelectedItem?.ToString() ?? "";
        _producto.Subcategoria = SubcategoriaPicker.SelectedItem?.ToString() ?? "";
        _producto.Estado = EstadoPicker.SelectedItem?.ToString() ?? "";

        await _firebaseHelper.UpdateProducto(_producto.Id, _producto);
        await DisplayAlert("Actualizado", "El estado ha sido actualizado", "OK");
        await Navigation.PopAsync(); // Regresar a la lista
    }
}
