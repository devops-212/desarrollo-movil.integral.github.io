﻿using System;
using System.Threading.Tasks;
using Microsoft.Maui.Controls;
using EcoDive_Integradora.Services;
using Firebase.Auth;
using System.Linq;

namespace EcoDive_Integradora.Views
{
    public partial class LoginPage : ContentPage
    {
        private const string FirebaseApiKey = "AIzaSyCf0ZvRcTZSjXa0f-ywnl4ZSJ0nbvdyEB0"; // Tu API Key de Firebase

        public LoginPage()
        {
            InitializeComponent();
        }

        private async void OnLoginClicked(object sender, EventArgs e)
        {
            string email = EmailEntry.Text?.Trim();
            string password = PasswordEntry.Text;

            var result = await FirebaseAuthService.Login(email, password);

            if (result != null)
            {
                string[] adminEmails = {
                    "boos-07-09@outlook.com",
                    "admin@ecodive.com"
                };

                bool esAdmin = adminEmails.Contains(result.Email, StringComparer.OrdinalIgnoreCase);

                if (esAdmin)
                {
                    await DisplayAlert("Bienvenido", $"¡Bienvenido, Administrador!\nCorreo: {result.Email}", "OK");
                    Application.Current.MainPage = new AdminShell(); // Solo para admins
                }
                else
                {
                    await DisplayAlert("Bienvenido", $"¡Bienvenido, Usuario!\nCorreo: {result.Email}", "OK");
                    Application.Current.MainPage = new AppShell(result.Email); // Solo para usuarios normales
                }
            }
            else
            {
                await DisplayAlert("Error", "Correo o contraseña incorrectos", "OK");
            }
        }

        private async void OnRegisterTapped(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new RegisterPage());
        }

        private async void OnForgotPasswordClicked(object sender, EventArgs e)
        {
            string email = await DisplayPromptAsync("Recuperar contraseña", "Introduce tu correo:");

            if (!string.IsNullOrEmpty(email))
            {
                var authProvider = new FirebaseAuthProvider(new FirebaseConfig(FirebaseApiKey));
                await authProvider.SendPasswordResetEmailAsync(email);
                await DisplayAlert("Correo enviado", "Revisa tu bandeja para restablecer tu contraseña", "OK");
            }
        }
    }
}
