﻿namespace EcoDive_Integradora.Models
{
    public class User
    {
        public string Id { get; set; } // Clave generada por Firebase
        public string Email { get; set; } // Puede ser un correo o nombre
        public string Password { get; set; } // Texto plano (aceptable solo para pruebas)
    }
}
